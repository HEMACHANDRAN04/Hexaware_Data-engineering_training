# Retail Order Management Platform

DevOps Capstone Project using:
- Flask
- GitHub
- GitHub Actions
- Pytest
- Trello